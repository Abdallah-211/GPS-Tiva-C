#include <stdint.h>

void TIMER_INIT(void);
void WAIT_FOR_10MS(uint32_t delay);
void number_of_10ms (uint32_t n);
