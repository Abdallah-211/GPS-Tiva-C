#define M_PI										3.141592653589793238462643383279502884197
//float distance;
float todegree(float angle);
float torad(float angle);
float calcdistance (float long1 , float lat1 , float long2 , float lat2);
