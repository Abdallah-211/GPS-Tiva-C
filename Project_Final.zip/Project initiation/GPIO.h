
void RGB_INIT (void);
void SW_INITI (void);
unsigned char SW1_Input (void);
unsigned char SW2_Input (void);
void LEDs_output(unsigned char data);
void LEDs_Clear(void);
