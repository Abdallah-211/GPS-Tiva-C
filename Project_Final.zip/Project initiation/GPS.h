
void GPS_format(void);
float GPS_format2(void);

